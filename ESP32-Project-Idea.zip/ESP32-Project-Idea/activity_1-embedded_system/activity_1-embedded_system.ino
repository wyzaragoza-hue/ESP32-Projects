// ESP32 Button-Controlled LED
// if button pressed, LED will on
// if button not pressed, button keep off
//Gnd of LEd

#define BUTTON_PIN 4 //pin connection of button to ESP32
#define LED_PIN 2 //pin connection of LED to ESP32

//setup button and LED 
void setup() {
  pinMode(BUTTON_PIN, INPUT_PULLUP); 
  pinMode(LED_PIN, OUTPUT);

  digitalWrite(LED_PIN, LOW);
}

void loop() {
  // Button is LOW when pressed
  if (digitalRead(BUTTON_PIN) == LOW) {
    digitalWrite(LED_PIN, HIGH);  // LED ON
  } 
  else {
    digitalWrite(LED_PIN, LOW);   // LED OFF
  }
}