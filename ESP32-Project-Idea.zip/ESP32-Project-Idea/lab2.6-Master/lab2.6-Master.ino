#include <SPI.h>

// ================================
// SPI PIN CONFIGURATION
// ================================
#define SCK_PIN   18
#define MISO_PIN  19
#define MOSI_PIN  23
#define CS_PIN     5

SPIClass spi(VSPI);

// Change this to test a specific mode
int spiMode = 0;

void setup() {
  Serial.begin(115200);
  delay(1000);

  // Configure SPI pins
  spi.begin(SCK_PIN, MISO_PIN, MOSI_PIN, CS_PIN);

  pinMode(CS_PIN, OUTPUT);
  digitalWrite(CS_PIN, HIGH);

  Serial.println();
  Serial.println("================================");
  Serial.println(" SPI CLOCK MODE INVESTIGATION");
  Serial.println("================================");

  setSPIMode(spiMode);
}

void loop() {

  // Send test data
  byte sendData = 0xA5;
  byte receivedData;

  spi.beginTransaction(
    SPISettings(
      1000000,        // 1 MHz
      MSBFIRST,       // Most Significant Bit First
      getSPIMode()    // SPI Mode
    )
  );

  // Select slave
  digitalWrite(CS_PIN, LOW);

  // Transfer one byte
  receivedData = spi.transfer(sendData);

  // Release slave
  digitalWrite(CS_PIN, HIGH);

  spi.endTransaction();

  Serial.print("Mode: ");
  Serial.print(spiMode);

  Serial.print(" | Sent: 0x");
  Serial.print(sendData, HEX);

  Serial.print(" | Received: 0x");
  Serial.println(receivedData, HEX);

  delay(1000);
}

// =================================
// SET SPI MODE
// =================================
void setSPIMode(int mode) {

  switch (mode) {

    case 0:
      spiMode = 0;
      Serial.println("SPI Mode 0 selected");
      Serial.println("CPOL = 0");
      Serial.println("CPHA = 0");
      Serial.println("Clock idle = LOW");
      break;

    case 1:
      spiMode = 1;
      Serial.println("SPI Mode 1 selected");
      Serial.println("CPOL = 0");
      Serial.println("CPHA = 1");
      Serial.println("Clock idle = LOW");
      break;

    case 2:
      spiMode = 2;
      Serial.println("SPI Mode 2 selected");
      Serial.println("CPOL = 1");
      Serial.println("CPHA = 0");
      Serial.println("Clock idle = HIGH");
      break;

    case 3:
      spiMode = 3;
      Serial.println("SPI Mode 3 selected");
      Serial.println("CPOL = 1");
      Serial.println("CPHA = 1");
      Serial.println("Clock idle = HIGH");
      break;

    default:
      spiMode = 0;
      Serial.println("Invalid mode. Using Mode 0.");
      break;
  }
}

// =================================
// GET SPI MODE
// =================================
uint8_t getSPIMode() {

  switch (spiMode) {

    case 0:
      return SPI_MODE0;

    case 1:
      return SPI_MODE1;

    case 2:
      return SPI_MODE2;

    case 3:
      return SPI_MODE3;

    default:
      return SPI_MODE0;
  }
}