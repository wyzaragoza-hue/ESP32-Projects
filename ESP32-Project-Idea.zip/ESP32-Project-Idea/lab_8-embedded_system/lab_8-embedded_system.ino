// 74HC165 Control Pins
const int DATA_PIN  = 19; // Q7 (Serial Data Output from 74HC165)
const int LATCH_PIN = 5;  // PL (Parallel Load)
const int CLOCK_PIN = 18; // CP (Clock)
const int CE_PIN    = 4;  // CE (Clock Enable)

void setup() {
  Serial.begin(115200);

  pinMode(DATA_PIN, INPUT);
  pinMode(LATCH_PIN, OUTPUT);
  pinMode(CLOCK_PIN, OUTPUT);
  pinMode(CE_PIN, OUTPUT);

  // Enable clock line permanently
  digitalWrite(CE_PIN, LOW);
  
  Serial.println("74HC165 Parallel Input Expansion Initialized.");
}

void loop() {
  // 1. Pulse LATCH_PIN LOW to sample parallel input states (A through H)
  digitalWrite(LATCH_PIN, LOW);
  delayMicroseconds(5);
  digitalWrite(LATCH_PIN, HIGH);

  // 2. Read 8-bit input data serially from the shift register
  byte switchValues = shiftIn(DATA_PIN, CLOCK_PIN, MSBFIRST);

  // 3. Display state in Serial Monitor
  Serial.print("Byte Read: 0b");
  for (int i = 7; i >= 0; i--) {
    Serial.print((switchValues >> i) & 1);
  }
  Serial.print("\t(Decimal: ");
  Serial.print(switchValues);
  Serial.println(")");

  delay(250); // Sample rate limit for clean readout
}