// ===================================================
// Laboratory Performance Task — SENDER
// ESP32 8-Bit ASCII Parallel Data Transmission
// ===================================================

//HARVY and WYNARD

const int dataPins[8] = {1, 2, 3, 4, 5, 6, 7, 8}; // Bit0..Bit7

void setup() {
  Serial.begin(115200);

  for (int i = 0; i < 8; i++) {
    pinMode(dataPins[i], OUTPUT);
    digitalWrite(dataPins[i], LOW);
  }

  Serial.println("=====================================");
  Serial.println(" SENDER READY");
  Serial.println(" Type a word and press Enter to send.");
  Serial.println("=====================================");
}

void loop() {
  if (Serial.available() > 0) {
    String word = Serial.readStringUntil('\n');
    word.trim(); // remove newline / trailing whitespace

    if (word.length() > 0) {
      Serial.print("Sending word: ");
      Serial.println(word);
      sendWord(word);
      Serial.println("Transmission complete.");
      Serial.println("-------------------------------------");
    }
  }
}

// Sends each character of the word, one at a time
void sendWord(String word) {
  for (int i = 0; i < word.length(); i++) {
    char c = word[i];
    uint8_t asciiValue = (uint8_t)c;

    sendByte(asciiValue);

    Serial.print("Char = '");
    Serial.print(c);
    Serial.print("'   ASCII = ");
    Serial.print(asciiValue);
    Serial.print("   Binary = ");
    printBinary8(asciiValue);
    Serial.println();

    delay(1000); // hold each character for ~1 second
  }

  // Optional: clear lines after sending the full word
  sendByte(0x00);
}

// Writes one 8-bit ASCII value to the 8 GPIO output lines (and LEDs)
void sendByte(uint8_t value) {
  for (int i = 0; i < 8; i++) {
    digitalWrite(dataPins[i], (value >> i) & 0x01);
  }
}

void printBinary8(uint8_t val) {
  for (int i = 7; i >= 0; i--) {
    Serial.print((val >> i) & 0x01);
  }
}