/*
  ESP32 Parallel Data Transmission - RECEIVER
  Laboratory 1 Performance Task
*/

const int dataPins[8] = {16, 17, 18, 19, 21, 22, 23, 25}; // LSB (Bit 0) to MSB (Bit 7)

String receivedWord = "";
bool isReceiving = false;
unsigned long lastChangeTime = 0;

void setup() {
  Serial.begin(115200);

  // Configure all data bus pins as INPUT with internal pull-downs
  for (int i = 0; i < 8; i++) {
    pinMode(dataPins[i], INPUT_PULLDOWN);
  }

  Serial.println("==========================================");
  Serial.println("     ESP32 PARALLEL RECEIVER READY        ");
  Serial.println("==========================================");
  Serial.println("Listening for incoming parallel signals...\n");
}

uint8_t readParallelBus() {
  uint8_t byteVal = 0;
  for (int bit = 0; bit < 8; bit++) {
    if (digitalRead(dataPins[bit]) == HIGH) {
      byteVal |= (1 << bit);
    }
  }
  return byteVal;
}

void loop() {
  uint8_t currentByte = readParallelBus();

  // Active state detection (Idle bus is 0x00)
  if (currentByte != 0x00) {
    if (!isReceiving) {
      isReceiving = true;
      receivedWord = "";
      Serial.println("--- Incoming Parallel Transmission ---");
    }

    char rxChar = (char)currentByte;
    receivedWord += rxChar;

    // Display formatted byte info
    Serial.print("Received Char: '");
    Serial.print(rxChar);
    Serial.print("' | Dec: ");
    if (currentByte < 100) Serial.print(" ");
    if (currentByte < 10)  Serial.print(" ");
    Serial.print(currentByte);
    Serial.print(" | Binary: ");

    for (int bit = 7; bit >= 0; bit--) {
      Serial.print((currentByte >> bit) & 0x01);
    }
    Serial.println();

    // Delay past the sender's 1-second transmission window to avoid duplicate sampling
    delay(1000);
    lastChangeTime = millis();
  }

  // Auto-detect end of message after 2 seconds of total bus idle state
  if (isReceiving && (millis() - lastChangeTime > 2000)) {
    Serial.println("------------------------------------------");
    Serial.print("Reconstructed Full Word: ");
    Serial.println(receivedWord);
    Serial.println("------------------------------------------\n");
    
    isReceiving = false;
    receivedWord = "";
  }

  delay(20); // Bus stability polling rate
}