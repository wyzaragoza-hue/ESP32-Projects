// Define the 8 GPIO pins connected to LED 0 (LSB) through LED 7 (MSB)
const int ledPins[8] = {13, 12, 14, 27, 26, 25, 33, 32};

// Array of 8-bit test patterns requested in the lab
const uint8_t testPatterns[] = {
  0b00000000,
  0b00000001,
  0b00000010,
  0b00000100,
  0b00001000,
  0b00010000,
  0b00100000,
  0b01000000,
  0b10000000,
  0b11111111,
  0b10101010,
  0b01010101
};

const int numPatterns = sizeof(testPatterns) / sizeof(testPatterns[0]);

// Helper function to write an 8-bit value to the parallel LED bus
void display8BitValue(uint8_t value) {
  for (int i = 0; i < 8; i++) {
    // Extract each bit using bitwise right-shift and bitwise AND
    int bitValue = (value >> i) & 0x01;
    digitalWrite(ledPins[i], bitValue);
  }
}

void setup() {
  Serial.begin(115200);

  // Initialize all 8 LED pins as digital outputs
  for (int i = 0; i < 8; i++) {
    pinMode(ledPins[i], OUTPUT);
    digitalWrite(ledPins[i], LOW);
  }

  Serial.println("--- Starting 8-Bit Test Patterns ---");
  
  // Step 1: Run through the requested test patterns
  for (int p = 0; p < numPatterns; p++) {
    uint8_t pattern = testPatterns[p];
    display8BitValue(pattern);
    
    Serial.print("Pattern ");
    Serial.print(p + 1);
    Serial.print(": 0b");
    for (int b = 7; b >= 0; b--) {
      Serial.print((pattern >> b) & 1);
    }
    Serial.println();
    
    delay(800); // Display each pattern for 800ms
  }

  Serial.println("\n--- Starting Challenge: 8-Bit Binary Counter (0 to 255) ---");
}

void loop() {
  // Step 2: Challenge - Count from 0 to 255 in binary
  for (int count = 0; count <= 255; count++) {
    display8BitValue((uint8_t)count);

    Serial.print("Value: ");
    Serial.print(count);
    Serial.print("\tBinary: 0b");
    for (int b = 7; b >= 0; b--) {
      Serial.print((count >> b) & 1);
    }
    Serial.println();

    delay(200); // 200ms step delay for readable counting speed
  }

  delay(1000); // Brief pause before restarting counter
}