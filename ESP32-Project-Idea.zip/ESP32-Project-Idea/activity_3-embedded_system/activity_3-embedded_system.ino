// Pin Definitions
const int COUNT_BUTTON_PIN = 2;
const int RESET_BUTTON_PIN = 3;

// Debounce Configuration
const unsigned long DEBOUNCE_DELAY = 50; // 50 milliseconds threshold

// Counter variable
int count = 0;

// State tracking for Count Button
int countButtonState = HIGH;
int countLastReading = HIGH;
unsigned long countLastDebounceTime = 0;

// State tracking for Reset Button
int resetButtonState = HIGH;
int resetLastReading = HIGH;
unsigned long resetLastDebounceTime = 0;

void setup() {
  Serial.begin(9600);
  
  // Configure pins with internal pull-up resistors
  pinMode(COUNT_BUTTON_PIN, INPUT_PULLUP);
  pinMode(RESET_BUTTON_PIN, INPUT_PULLUP);
  
  Serial.println("System Ready! Initial Count: 0");
}

void loop() {
  // -----------------------------
  // 1. Process Count Button
  // -----------------------------
  int countReading = digitalRead(COUNT_BUTTON_PIN);

  // Check if button state changed due to press or mechanical bounce
  if (countReading != countLastReading) {
    countLastDebounceTime = millis(); // Reset debounce timer
  }

  // If reading has remained stable longer than debounce threshold
  if ((millis() - countLastDebounceTime) > DEBOUNCE_DELAY) {
    if (countReading != countButtonState) {
      countButtonState = countReading;

      // Increment count on button press (LOW state due to INPUT_PULLUP)
      if (countButtonState == LOW) {
        count++;
        Serial.print("Debounced Count: ");
        Serial.println(count);
      }
    }
  }
  countLastReading = countReading;

  // -----------------------------
  // 2. Process Reset Button
  // -----------------------------
  int resetReading = digitalRead(RESET_BUTTON_PIN);

  if (resetReading != resetLastReading) {
    resetLastDebounceTime = millis();
  }

  if ((millis() - resetLastDebounceTime) > DEBOUNCE_DELAY) {
    if (resetReading != resetButtonState) {
      resetButtonState = resetReading;

      // Reset count on button press
      if (resetButtonState == LOW) {
        count = 0;
        Serial.println("Counter Reset to 0!");
      }
    }
  }
  resetLastReading = resetReading;
}