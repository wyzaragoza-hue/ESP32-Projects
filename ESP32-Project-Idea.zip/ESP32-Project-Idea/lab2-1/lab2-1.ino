//UART Communication Between Two ESP32 Boards

HardwareSerial MySerial(2);

void setup() {
  Serial.begin(115200);

  // UART2: RX = GPIO16, TX = GPIO17
  MySerial.begin(9600, SERIAL_8N1, 16, 17);

  Serial.println("ESP32 A - UART Transmitter");
}

void loop() {
  MySerial.println("Hello from ESP32 A");
  delay(1000);
}

//Receive
//HardwareSerial MySerial(2);

//void setup() {
  //Serial.begin(115200);

  // UART2: RX = GPIO16, TX = GPIO17:com
  //MySerial.begin(9600, SERIAL_8N1, 16, 17);

  //Serial.println("ESP32 B - UART Receiver");
//}

//void loop() {
  //if (MySerial.available()) {
    //String message = MySerial.readStringUntil('\n');

    //Serial.print("Received: ");
    //Serial.println(message);
  //}
//}