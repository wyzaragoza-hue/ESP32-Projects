// ==========================================
// ESP32 A - UART COMMAND CONTROLLER
// ==========================================

// Use UART2
HardwareSerial MySerial(2);

// UART pins
const int RX_PIN = 16;
const int TX_PIN = 17;

void setup() {

  // USB Serial Monitor
  Serial.begin(115200);

  // UART communication with ESP32 B
  MySerial.begin(9600, SERIAL_8N1, RX_PIN, TX_PIN);

  Serial.println();
  Serial.println("================================");
  Serial.println(" ESP32 A - COMMAND CONTROLLER");
  Serial.println("================================");
  Serial.println("Type:");
  Serial.println("ON     - Turn LED ON");
  Serial.println("OFF    - Turn LED OFF");
  Serial.println("STATUS - Check LED status");
  Serial.println();
}

void loop() {

  // Check if user typed something
  if (Serial.available()) {

    // Read command from Serial Monitor
    String command = Serial.readStringUntil('\n');

    // Remove spaces and newline characters
    command.trim();

    // Convert command to uppercase
    command.toUpperCase();

    // Check valid commands
    if (command == "ON") {

      MySerial.println("ON");

      Serial.println("Command sent: ON");
    }

    else if (command == "OFF") {

      MySerial.println("OFF");

      Serial.println("Command sent: OFF");
    }

    else if (command == "STATUS") {

      MySerial.println("STATUS");

      Serial.println("Command sent: STATUS");
    }

    else {

      Serial.println("Invalid command!");
      Serial.println("Use ON, OFF, or STATUS.");
    }
  }

  // Check if ESP32 B sent a response
  if (MySerial.available()) {

    String response = MySerial.readStringUntil('\n');

    response.trim();

    Serial.print("ESP32 B: ");
    Serial.println(response);
  }
}