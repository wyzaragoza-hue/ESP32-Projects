// =====================================================
// LABORATORY 2.5
// SPI COMMUNICATION BETWEEN TWO ESP32 BOARDS
//
// ESP32 SLAVE
// =====================================================

#include <Arduino.h>
#include "driver/spi_slave.h"

// -----------------------------------------------------
// SPI PIN CONFIGURATION
// -----------------------------------------------------

#define SCK_PIN   18
#define MISO_PIN  19
#define MOSI_PIN  23
#define CS_PIN     5

// -----------------------------------------------------
// SPI BUFFERS
// -----------------------------------------------------

uint8_t rx_data[1];
uint8_t tx_data[1];

// SPI transaction structure
spi_slave_transaction_t transaction;

void setup() {

  // Serial Monitor
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println("================================");
  Serial.println(" ESP32 SPI SLAVE");
  Serial.println("================================");

  // ---------------------------------------------------
  // Configure SPI pins
  // ---------------------------------------------------

  spi_bus_config_t buscfg = {
    .mosi_io_num = MOSI_PIN,
    .miso_io_num = MISO_PIN,
    .sclk_io_num = SCK_PIN,
    .quadwp_io_num = -1,
    .quadhd_io_num = -1,
    .max_transfer_sz = 8
  };

  // ---------------------------------------------------
  // Configure SPI Slave
  // ---------------------------------------------------

  spi_slave_interface_config_t slvcfg = {
    .spics_io_num = CS_PIN,

    .flags = 0,

    .queue_size = 1,

    .mode = 0,

    .post_setup_cb = NULL,

    .post_trans_cb = NULL
  };

  // ---------------------------------------------------
  // Initialize VSPI as SPI Slave
  // ---------------------------------------------------

  esp_err_t result = spi_slave_initialize(
    VSPI_HOST,
    &buscfg,
    &slvcfg,
    SPI_DMA_DISABLED
  );

  if (result != ESP_OK) {

    Serial.println("SPI Slave initialization FAILED!");

    while (1) {
      delay(1000);
    }
  }

  Serial.println("SPI Slave initialized successfully.");
  Serial.println("SPI Mode: 0");
  Serial.println("CPOL = 0");
  Serial.println("CPHA = 0");
  Serial.println("Clock Idle = LOW");
  Serial.println();
  Serial.println("Waiting for ESP32 Master...");
}

// =====================================================
// MAIN LOOP
// =====================================================

void loop() {

  // ---------------------------------------------------
  // Prepare data to send to Master
  // ---------------------------------------------------

  tx_data[0] = 0xAA;

  // Clear receive buffer
  rx_data[0] = 0x00;

  // Clear transaction structure
  memset(&transaction, 0, sizeof(transaction));

  // Number of bits to transfer
  transaction.length = 8;

  // Data to send
  transaction.tx_buffer = tx_data;

  // Data received
  transaction.rx_buffer = rx_data;

  // ---------------------------------------------------
  // Wait for Master to start SPI transaction
  // ---------------------------------------------------

  esp_err_t result = spi_slave_transmit(
    VSPI_HOST,
    &transaction,
    portMAX_DELAY
  );

  // ---------------------------------------------------
  // Check transaction result
  // ---------------------------------------------------

  if (result == ESP_OK) {

    Serial.print("Received from Master: 0x");

    if (rx_data[0] < 0x10) {
      Serial.print("0");
    }

    Serial.println(rx_data[0], HEX);

    Serial.println("Sent to Master: 0xAA");
    Serial.println("--------------------------------");
  }

  else {

    Serial.println("SPI transaction failed!");
  }
}