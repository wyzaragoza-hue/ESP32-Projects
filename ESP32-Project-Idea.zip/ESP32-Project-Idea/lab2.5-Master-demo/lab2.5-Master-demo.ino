#include <SPI.h>

#define SCK_PIN  18
#define MISO_PIN 19
#define MOSI_PIN 23
#define CS_PIN   5

SPIClass spi(VSPI);

void setup() {
  Serial.begin(115200);

  spi.begin(SCK_PIN, MISO_PIN, MOSI_PIN, CS_PIN);
  pinMode(CS_PIN, OUTPUT);
  digitalWrite(CS_PIN, HIGH);

  Serial.println("SPI Master Ready");
}

void loop() {
  digitalWrite(CS_PIN, LOW);

  spi.beginTransaction(
    SPISettings(1000000, MSBFIRST, SPI_MODE0)
  );

  uint8_t received = spi.transfer(0x55);

  spi.endTransaction();

  digitalWrite(CS_PIN, HIGH);

  Serial.print("Received: 0x");
  Serial.println(received, HEX);

  delay(1000);
}