const int BUTTON_PIN = 4;
volatile int count = 0;

// Interrupt Service Routine (ISR)
void IRAM_ATTR handleInterrupt() {
  count++;
}

void setup() {
  Serial.begin(115200);
  
  // Internal pull-up keeps pin HIGH until pressed (LOW)
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  
  // Trigger interrupt when pin transitions from HIGH to LOW
  attachInterrupt(digitalPinToInterrupt(BUTTON_PIN), handleInterrupt, FALLING);
}

void loop() {
  static int lastCount = 0;

  // Print to Serial Monitor whenever the interrupt increments count
  if (count != lastCount) {
    Serial.print("Interrupt Count: ");
    Serial.println(count);
    lastCount = count;
  }
}