//lab2.3 ESP32-Master


#include <Wire.h>

#define SLAVE_ADDRESS 0x08

void setup() {
  Serial.begin(115200);

  Wire.begin(21, 22);

  Serial.println("I2C Master Ready");
}

void loop() {
  const char message[] = "HELLO";

  Wire.beginTransmission(SLAVE_ADDRESS);
  Wire.write((const uint8_t*)message, sizeof(message) - 1);

  uint8_t result = Wire.endTransmission();

  Serial.print("Transmission result: ");
  Serial.println(result);

  delay(1000);
}