// ESP32 Transistor Switching & PWM Control
const int LOAD_PIN = 18; // GPIO connected to transistor base/gate

void setup() {
  Serial.begin(115200);
  
  // Configure pin as digital output
  pinMode(LOAD_PIN, OUTPUT);
  digitalWrite(LOAD_PIN, LOW); // Ensure load is OFF initially
  
  Serial.println("Transistor Interface Initialized.");
}

void loop() {
  // Step 1: Turn Load Fully ON
  Serial.println("Load status: ON");
  digitalWrite(LOAD_PIN, HIGH);
  delay(3000);

  // Step 2: Turn Load Fully OFF
  Serial.println("Load status: OFF");
  digitalWrite(LOAD_PIN, LOW);
  delay(3000);

  // Step 3: Demonstrate Variable Power Control using PWM (Analog Write)
  Serial.println("Ramping Load Power UP (0% to 100%)...");
  for (int dutyCycle = 0; dutyCycle <= 255; dutyCycle += 5) {
    analogWrite(LOAD_PIN, dutyCycle);
    delay(50);
  }
  
  delay(1000);
  digitalWrite(LOAD_PIN, LOW);
  delay(2000);
}