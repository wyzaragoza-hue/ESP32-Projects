// 74HC595 Control Pins
const int DATA_PIN  = 23; // DS (Data)
const int LATCH_PIN = 5;  // ST_CP (Latch)
const int CLOCK_PIN = 18; // SH_CP (Clock)

void setup() {
  Serial.begin(115200);

  // Set control pins as outputs
  pinMode(DATA_PIN, OUTPUT);
  pinMode(LATCH_PIN, OUTPUT);
  pinMode(CLOCK_PIN, OUTPUT);

  Serial.println("74HC595 8-Bit Binary Counter Started!");
}

void loop() {
  // Challenge: Count from 0 to 255
  for (int count = 0; count <= 255; count++) {
    // Pull LATCH LOW so LEDs don't flicker while shifting data
    digitalWrite(LATCH_PIN, LOW);

    // Shift out the 8-bit binary data (MSBFIRST sends bit 7 down to bit 0)
    shiftOut(DATA_PIN, CLOCK_PIN, MSBFIRST, (byte)count);

    // Pull LATCH HIGH to update the parallel output pins (Q0-Q7)
    digitalWrite(LATCH_PIN, HIGH);

    // Serial monitor debugging
    Serial.print("Decimal: ");
    Serial.print(count);
    Serial.print("\tBinary: 0b");
    for (int b = 7; b >= 0; b--) {
      Serial.print((count >> b) & 1);
    }
    Serial.println();

    delay(150); // Speed of the counting animation
  }

  delay(1000); // Wait 1 second before restarting count
}