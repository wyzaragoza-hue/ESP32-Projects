#include <ESP32SPISlave.h>

ESP32SPISlave slave;

// =================================
// SPI PINS
// =================================
#define SCK_PIN   18
#define MISO_PIN  19
#define MOSI_PIN  23
#define CS_PIN     5

// Buffer for SPI communication
uint8_t tx_buf[1];
uint8_t rx_buf[1];

void setup() {

  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println("================================");
  Serial.println(" SPI SLAVE");
  Serial.println("================================");

  // Initialize SPI slave
  slave.setDataMode(SPI_MODE0);

  slave.setQueueSize(1);

  slave.begin(
    VSPI,
    SCK_PIN,
    MISO_PIN,
    MOSI_PIN,
    CS_PIN
  );

  tx_buf[0] = 0x5A;

  Serial.println("SPI Slave Ready");
  Serial.println("Current Mode: 0");
}

void loop() {

  // Wait for SPI transaction
  if (slave.remained()) {

    // Wait until transaction completes
    slave.wait();

    Serial.print("Received: 0x");

    Serial.println(rx_buf[0], HEX);

    // Prepare next response
    tx_buf[0] = 0x5A;

    // Queue another transaction
    slave.queue(tx_buf, rx_buf, 1);
  }
}