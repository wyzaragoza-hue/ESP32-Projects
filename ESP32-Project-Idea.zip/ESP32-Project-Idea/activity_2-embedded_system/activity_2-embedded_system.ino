// ==========================================
// LABORATORY 1.2
// 4-Bit Parallel Input Using ESP32
// ==========================================

// Button GPIO pins
const int B3_BUTTON = 18;
const int B2_BUTTON = 19;
const int B1_BUTTON = 21;
const int B0_BUTTON = 22;

void setup() {
  Serial.begin(115200);

  // Configure buttons as inputs with internal pull-up
  pinMode(B3_BUTTON, INPUT_PULLUP);
  pinMode(B2_BUTTON, INPUT_PULLUP);
  pinMode(B1_BUTTON, INPUT_PULLUP);
  pinMode(B0_BUTTON, INPUT_PULLUP);

  Serial.println("================================");
  Serial.println("  4-BIT PARALLEL INPUT - ESP32");
  Serial.println("================================");
}

void loop() {

  // Read each button
  int bit3 = !digitalRead(B3_BUTTON);
  int bit2 = !digitalRead(B2_BUTTON);
  int bit1 = !digitalRead(B1_BUTTON);
  int bit0 = !digitalRead(B0_BUTTON);

  // Combine the four bits
  int value = (bit3 << 3) |
              (bit2 << 2) |
              (bit1 << 1) |
              bit0;

  // Display binary value
  Serial.print("Binary = ");
  Serial.print(bit3);
  Serial.print(bit2);
  Serial.print(bit1);
  Serial.print(bit0);

  // Display decimal value
  Serial.print("    Decimal = ");
  Serial.println(value);

  delay(200);
}