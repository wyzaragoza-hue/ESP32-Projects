//lab2.3 - ESP32-Slave

#include <Wire.h>

#define I2C_ADDRESS 0x08

void receiveEvent(int howMany) {
  while (Wire.available()) {
    char c = Wire.read();
    Serial.print(c);
  }
  Serial.println();
}

void setup() {
  Serial.begin(115200);

  Wire.begin(I2C_ADDRESS);
  Wire.onReceive(receiveEvent);

  Serial.println("I2C Slave Ready");
}

void loop() {
  delay(10);
}