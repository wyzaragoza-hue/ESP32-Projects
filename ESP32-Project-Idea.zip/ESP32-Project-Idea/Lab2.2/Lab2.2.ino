HardwareSerial MySerial(2);

const int LED_PIN = 2;
String command = "";

void setup() {
  pinMode(LED_PIN, OUTPUT);

  Serial.begin(115200);
  MySerial.begin(9600, SERIAL_8N1, 16, 17);

  Serial.println("Command Receiver Ready");
}

void loop() {
  if (MySerial.available()) {
    command = MySerial.readStringUntil('\n');
    command.trim();

    if (command == "ON") {
      digitalWrite(LED_PIN, HIGH);
      MySerial.println("LED is ON");
    }
    else if (command == "OFF") {
      digitalWrite(LED_PIN, LOW);
      MySerial.println("LED is OFF");
    }
    else if (command == "STATUS") {
      MySerial.println(digitalRead(LED_PIN) ? "LED=ON" : "LED=OFF");
    }
    else {
      MySerial.println("UNKNOWN COMMAND");
    }
  }
}

